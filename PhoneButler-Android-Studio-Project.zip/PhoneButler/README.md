# Phone Butler

An offline-first Android companion starter built with Kotlin, Jetpack Compose, Material 3, Room, MVVM and WorkManager.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `PhoneButler` folder in Android Studio.
3. Use JDK 17.
4. Allow Gradle sync to finish.
5. Run on an Android 8.0+ device or emulator.

## Included
- Dark Compose UI with Butler room, game profiles, reports and rules screens.
- Room database for game profiles, reports and key/value memories.
- Local weighted game-selection engine with offline-only filtering, battery floor, time budget, preference and recency.
- Battery and free-storage snapshot.
- Personality dialogue seed lines.
- WorkManager worker foundation.
- Passive accessibility service declaration, disabled until the user explicitly enables it.

## Important Android limits
This project does **not** secretly play third-party games. Android does not provide a supported general-purpose API for an app to operate other apps while the phone is locked or while its owner is away. Accessibility-driven taps are not a safe or reliable substitute, can violate game terms, and must never be used to bypass anti-cheat systems. Some games also pause or disconnect when backgrounded.

Likewise, ordinary third-party apps cannot universally clear other apps' caches, force-stop arbitrary apps, update every installed app, or download content without the relevant app/service and user authorization. The starter therefore reports phone metrics and plans sessions rather than claiming to perform impossible work.

## Next implementation milestones
- Add onboarding screens and persist profile preferences in `memories`.
- Add user-managed Do Not Touch list and actual school/bedtime schedule persistence.
- Add UsageStatsManager access flow with an explicit explanation and Settings deep link.
- Add notification permission flow and scheduled local reports.
- Add Storage Access Framework file cleanup for files the user selects.
- Add user-initiated download manager with a visible notification.
- Add per-game deep links only where each game officially supports them.
- Add unit tests for ButlerBrain scoring and rule enforcement.

## Safety design
- Online game autoplay list is empty.
- Online titles are not selected by the local brain.
- Battery stop defaults to 20%.
- No game automation, anti-cheat bypass, hidden data collection, or remote control.
- No cloud dependency is required for core screens and decision logic.

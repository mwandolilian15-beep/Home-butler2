package com.phonebutler.brain

import com.phonebutler.data.ButlerDao
import com.phonebutler.data.GameProfile

class GameProfileManager(private val dao: ButlerDao) {
    suspend fun seedIfEmpty() {
        if (dao.allGames().isNotEmpty()) return
        dao.upsertGames(listOf(
            GameProfile("minecraft", "Minecraft", "Farm, mine and gather resources", "wood, food, ores", 3, 25, 12, "Supplies and XP"),
            GameProfile("gta_sa", "GTA San Andreas", "Drive and complete safe story activities", "cash and progress", 3, 20, 14, "Cash and progress"),
            GameProfile("truckers", "Truckers of Europe", "Complete delivery routes", "money and XP", 2, 25, 13, "Money and XP"),
            GameProfile("fifa14", "FIFA 14", "Play easy career matches", "career progress", 2, 20, 12, "Career progress"),
            GameProfile("piano_fire", "Piano Fire", "Practice songs and improve scores", "score", 2, 12, 8, "High score"),
            GameProfile("fruit_fancy", "Fruit Fancy", "Complete offline match levels", "points", 1, 15, 7, "Points"),
            GameProfile("mad_hill", "Mad Hill Racing", "Race and collect coins", "coins", 2, 15, 10, "Coins"),
            GameProfile("tekken_ppsspp", "Tekken 3 (PPSSPP)", "Play arcade matches", "wins", 3, 20, 13, "Wins"),
            GameProfile("cod_boz", "COD:BOZ Zombies", "Survive offline zombie rounds", "XP", 4, 15, 16, "XP")
        ))
    }

    fun maintenanceOnlyOnlineGames() = listOf("Call of Duty Mobile", "FC Mobile", "Mini Militia online mode")
}

package com.phonebutler.report

import com.phonebutler.data.ButlerDao
import com.phonebutler.data.ButlerReport
import com.phonebutler.data.GameDecision

class ReportManager(private val dao: ButlerDao) {
    suspend fun recordPlan(decision: GameDecision, nextGame: String) {
        dao.addReport(
            ButlerReport(
                gameName = decision.profile.name,
                reason = decision.reason,
                reward = "Planned only: ${decision.profile.reward}",
                nextGame = nextGame
            )
        )
        dao.markPlayed(decision.profile.id, System.currentTimeMillis())
    }
}

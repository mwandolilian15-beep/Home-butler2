package com.phonebutler.brain

class PersonalityManager {
    private val greetings = listOf(
        "Ba boss, welcome back. The room is still standing. You're welcome.",
        "Boss is back! I kept things tidy. Mostly.",
        "Welcome back. Your phone and I have had a productive little meeting."
    )
    private val idle = listOf(
        "I'm just here guarding these pixels.",
        "Any tasks? No? I'll keep the room in order.",
        "This silence is louder than a school assembly."
    )
    private val reports = listOf(
        "Report ready, boss. No drama, just the facts.",
        "Here is what happened while you were away.",
        "Shift complete. Please inspect my extremely digital hard work."
    )
    fun greeting() = greetings.random()
    fun idleLine() = idle.random()
    fun reportLine() = reports.random()
    fun explainNoAutoplay() = "I can plan and track game sessions, but Android does not let me secretly play other apps in the background."
}

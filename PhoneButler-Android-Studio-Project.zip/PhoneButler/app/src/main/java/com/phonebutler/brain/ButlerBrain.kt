package com.phonebutler.brain

import com.phonebutler.data.GameDecision
import com.phonebutler.data.GameProfile
import com.phonebutler.data.PhoneSnapshot
import kotlin.math.max

class ButlerBrain {
    fun choose(
        games: List<GameProfile>,
        phone: PhoneSnapshot,
        timeAvailableMinutes: Int,
        doNotTouch: Set<String> = emptySet(),
        batteryLimit: Int = 20
    ): GameDecision? {
        if (phone.batteryPercent < batteryLimit || timeAvailableMinutes < 5) return null
        val eligible = games.filter {
            it.enabled && it.offline && it.id !in doNotTouch &&
                it.durationMinutes <= timeAvailableMinutes &&
                it.batteryCost <= max(0, phone.batteryPercent - batteryLimit)
        }
        if (eligible.isEmpty()) return null

        val now = System.currentTimeMillis()
        val ranked = eligible.map { game ->
            val hoursSince = if (game.lastPlayedAt == 0L) 999.0
                else (now - game.lastPlayedAt).coerceAtLeast(0) / 3_600_000.0
            val recencyScore = (hoursSince / 24.0).coerceIn(0.0, 5.0)
            val score = game.preference * 2.0 + recencyScore -
                game.difficulty * 0.7 - game.batteryCost * 0.35
            game to score
        }.sortedByDescending { it.second }

        val chosen = ranked.first().first
        val reason = "I picked ${chosen.name}: it fits the time window, is marked offline, " +
            "has a manageable battery cost, and has not been played recently."
        return GameDecision(chosen, reason, minOf(chosen.durationMinutes, timeAvailableMinutes))
    }
}

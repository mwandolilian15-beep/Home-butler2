package com.phonebutler

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.phonebutler.ui.PhoneButlerApp
import com.phonebutler.ui.theme.PhoneButlerTheme
import com.phonebutler.viewmodel.ButlerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PhoneButlerTheme {
                val vm: ButlerViewModel = viewModel()
                PhoneButlerApp(vm)
            }
        }
    }
}

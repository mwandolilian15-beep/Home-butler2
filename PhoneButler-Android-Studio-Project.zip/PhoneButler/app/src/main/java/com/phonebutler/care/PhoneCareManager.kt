package com.phonebutler.care

import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import com.phonebutler.data.PhoneSnapshot

class PhoneCareManager(private val context: Context) {
    fun snapshot(): PhoneSnapshot {
        val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            .takeIf { it in 0..100 } ?: 0
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = stat.availableBytes / (1024 * 1024)
        val total = stat.totalBytes / (1024 * 1024)
        return PhoneSnapshot(
            batteryPercent = battery,
            storageFreeMb = free,
            storageTotalMb = total,
            isCharging = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) == 2
        )
    }

    // Android intentionally does not expose a universal API for silently clearing
    // another app's cache or force-stopping arbitrary apps.
    fun safeCareSummary(snapshot: PhoneSnapshot): String =
        "Battery ${snapshot.batteryPercent}% • ${snapshot.storageFreeMb} MB free"
}

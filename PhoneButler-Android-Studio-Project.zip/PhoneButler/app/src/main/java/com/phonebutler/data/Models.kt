package com.phonebutler.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_profiles")
data class GameProfile(
    @PrimaryKey val id: String,
    val name: String,
    val job: String,
    val targetResource: String,
    val difficulty: Int,
    val durationMinutes: Int,
    val batteryCost: Int,
    val reward: String,
    val offline: Boolean = true,
    val preference: Int = 5,
    val lastPlayedAt: Long = 0L,
    val enabled: Boolean = true
)

@Entity(tableName = "reports")
data class ButlerReport(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val gameName: String,
    val reason: String,
    val reward: String,
    val storageCleanedMb: Long = 0,
    val downloadsCompleted: Int = 0,
    val batterySavedPercent: Int = 0,
    val nextGame: String
)

@Entity(tableName = "memories")
data class ButlerMemory(
    @PrimaryKey val key: String,
    val value: String
)

data class PhoneSnapshot(
    val batteryPercent: Int,
    val storageFreeMb: Long,
    val storageTotalMb: Long,
    val isCharging: Boolean
)

data class GameDecision(
    val profile: GameProfile,
    val reason: String,
    val plannedMinutes: Int
)

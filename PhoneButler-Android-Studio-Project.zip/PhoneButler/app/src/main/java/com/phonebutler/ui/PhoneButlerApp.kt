package com.phonebutler.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.phonebutler.viewmodel.ButlerViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF101522)
private val Panel = Color(0xFF1C2638)
private val Mint = Color(0xFF65E6C2)
private val Muted = Color(0xFF9EABC0)

@Composable
fun PhoneButlerApp(vm: ButlerViewModel) {
    var tab by remember { mutableStateOf(0) }
    val games by vm.games.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val phone = vm.snapshot()

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text("Room") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("Games") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Assessment, null) }, label = { Text("Reports") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Rules") })
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(vm, phone, Modifier.padding(padding))
            1 -> GamesScreen(games, Modifier.padding(padding))
            2 -> ReportsScreen(reports, Modifier.padding(padding))
            else -> RulesScreen(Modifier.padding(padding))
        }
    }
}

@Composable
private fun HomeScreen(vm: ButlerViewModel, phone: com.phonebutler.data.PhoneSnapshot, modifier: Modifier) {
    var minutes by remember { mutableIntStateOf(30) }
    LazyColumn(
        modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF18253A), Night))),
        contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("PHONE BUTLER", color = Mint, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text("His room", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(26.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🧑🏾‍💼", style = MaterialTheme.typography.displayLarge)
                    Text("Benson the Butler", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Status: waiting in his room", color = Mint)
                    Spacer(Modifier.height(12.dp))
                    Text("“${vm.dialogue}”", color = Color(0xFFE1E8F2))
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = vm::talk) { Text("Talk") }
                        Button(onClick = { vm.planSession(minutes) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) {
                            Text("Make a plan")
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Battery", "${phone.batteryPercent}%", Modifier.weight(1f))
                MetricCard("Free storage", "${phone.storageFreeMb} MB", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Time budget", color = Color.White, fontWeight = FontWeight.Bold)
                    Slider(value = minutes.toFloat(), onValueChange = { minutes = it.toInt() }, valueRange = 5f..60f, steps = 10)
                    Text("$minutes minutes", color = Mint)
                }
            }
        }
        item {
            Text("Important reality check", color = Mint, fontWeight = FontWeight.Bold)
            Text("Phone Butler can choose games, track profiles and create reports. It cannot secretly play games while the phone is locked or the user is away. Android isolates apps and games may prohibit automation.", color = Muted)
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun GamesScreen(games: List<com.phonebutler.data.GameProfile>, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Offline game profiles", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
        items(games) { game ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.fillMaxWidth().padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(game.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(if (game.offline) "OFFLINE" else "ONLINE", color = Mint, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(game.job, color = Muted)
                    Spacer(Modifier.height(6.dp))
                    Text("Target: ${game.targetResource} • ${game.durationMinutes} min • Battery cost ${game.batteryCost}%", color = Color(0xFFD5DEEA), style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(progress = { game.preference / 10f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Mint)
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(reports: List<com.phonebutler.data.ButlerReport>, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Shift reports", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
        if (reports.isEmpty()) item { Text("No reports yet. A butler cannot report on a shift that never happened. Details matter.", color = Muted) }
        items(reports) { report ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text(report.gameName, color = Mint, fontWeight = FontWeight.Bold)
                    Text(report.reason, color = Color.White)
                    Text(report.reward, color = Muted)
                    Text("Next planned: ${report.nextGame}", color = Muted)
                    Text(SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(report.createdAt)), color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun RulesScreen(modifier: Modifier) {
    var battery by remember { mutableFloatStateOf(20f) }
    var schoolMode by remember { mutableStateOf(false) }
    var bedtime by remember { mutableStateOf(true) }
    LazyColumn(modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Rules & safety", color = Color.White, style = MaterialTheme.typography.headlineSmall) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Battery stop limit: ${battery.toInt()}%", color = Color.White, fontWeight = FontWeight.Bold)
                    Slider(value = battery, onValueChange = { battery = it }, valueRange = 20f..60f, steps = 7)
                    Text("Gaming plans stop when battery falls below this level.", color = Muted)
                }
            }
        }
        item { SettingSwitch("School mode", schoolMode) { schoolMode = it } }
        item { SettingSwitch("Bedtime mode", bedtime) { bedtime = it } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Permissions", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("This starter requests no broad access by default. Accessibility is optional and passive. Usage access must be enabled manually in Android Settings if added later.", color = Muted)
                }
            }
        }
        item {
            Text("Do not touch list and schedules are UI placeholders in this starter. No app is force-stopped, no cache is silently deleted, and no game is controlled.", color = Muted)
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

package com.phonebutler.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ButlerDao {
    @Query("SELECT * FROM game_profiles ORDER BY name")
    fun observeGames(): Flow<List<GameProfile>>

    @Query("SELECT * FROM game_profiles")
    suspend fun allGames(): List<GameProfile>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGames(games: List<GameProfile>)

    @Query("UPDATE game_profiles SET lastPlayedAt = :time WHERE id = :id")
    suspend fun markPlayed(id: String, time: Long)

    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun observeReports(): Flow<List<ButlerReport>>

    @Insert
    suspend fun addReport(report: ButlerReport)

    @Query("SELECT * FROM memories WHERE `key` = :key LIMIT 1")
    suspend fun memory(key: String): ButlerMemory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMemory(memory: ButlerMemory)
}

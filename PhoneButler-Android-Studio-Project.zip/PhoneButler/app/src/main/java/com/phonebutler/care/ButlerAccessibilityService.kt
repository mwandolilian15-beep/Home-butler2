package com.phonebutler.care

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Deliberately passive starter service. It does not inspect screen contents,
 * tap controls, launch games, or automate gameplay.
 */
class ButlerAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}

package com.phonebutler.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [GameProfile::class, ButlerReport::class, ButlerMemory::class],
    version = 1,
    exportSchema = false
)
abstract class ButlerDatabase : RoomDatabase() {
    abstract fun dao(): ButlerDao

    companion object {
        @Volatile private var INSTANCE: ButlerDatabase? = null
        fun get(context: Context): ButlerDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, ButlerDatabase::class.java, "phone-butler.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}

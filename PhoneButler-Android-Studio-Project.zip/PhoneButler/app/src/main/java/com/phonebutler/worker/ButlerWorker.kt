package com.phonebutler.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Background worker is intentionally limited to local planning/maintenance.
 * It must not launch games or simulate user input.
 */
class ButlerWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        // Add scheduled local checks here. Keep work short and battery-conscious.
        return Result.success()
    }
}

package com.phonebutler.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.phonebutler.brain.ButlerBrain
import com.phonebutler.brain.GameProfileManager
import com.phonebutler.brain.PersonalityManager
import com.phonebutler.care.PhoneCareManager
import com.phonebutler.data.ButlerDatabase
import com.phonebutler.data.GameDecision
import com.phonebutler.data.PhoneSnapshot
import com.phonebutler.report.ReportManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ButlerViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = ButlerDatabase.get(app).dao()
    private val profiles = GameProfileManager(dao)
    private val brain = ButlerBrain()
    private val care = PhoneCareManager(app)
    private val reportsManager = ReportManager(dao)
    private val personality = PersonalityManager()

    val games = dao.observeGames().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reports = dao.observeReports().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var dialogue = personality.greeting()
        private set
    var lastDecision: GameDecision? = null
        private set

    init { viewModelScope.launch { profiles.seedIfEmpty() } }

    fun snapshot(): PhoneSnapshot = care.snapshot()
    fun talk() { dialogue = personality.idleLine() }

    fun planSession(minutes: Int = 30) {
        viewModelScope.launch {
            val snap = care.snapshot()
            val decision = brain.choose(dao.allGames(), snap, minutes)
            lastDecision = decision
            if (decision == null) {
                dialogue = if (snap.batteryPercent < 20) "Battery is below 20%. I'm putting gaming on pause."
                    else "No safe offline session fits the current time and battery rules."
            } else {
                dialogue = decision.reason + " Note: this is a plan, not an automated game session."
                reportsManager.recordPlan(decision, "Re-evaluate next time")
            }
        }
    }
}

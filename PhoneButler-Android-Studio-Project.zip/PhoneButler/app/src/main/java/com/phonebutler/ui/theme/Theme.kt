package com.phonebutler.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFF65E6C2),
    secondary = Color(0xFF8FA8FF),
    background = Color(0xFF101522),
    surface = Color(0xFF1C2638)
)

@Composable
fun PhoneButlerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
